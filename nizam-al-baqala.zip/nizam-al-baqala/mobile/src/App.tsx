// Mobile Manager APK - Reports only
// تقارير + حركة يومية + ذمم

export default function App(){return <div>نظام البقالة - Manager APK</div>}