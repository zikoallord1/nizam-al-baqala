-- نظام البقالة المحاسبي - Supabase Schema
-- Offline/Online Sync Tables

-- 1. الأصناف مع العبوات
create table items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  barcode text unique,
  purchase_price numeric,
  sale_price numeric,
  expiry_date date,
  stock_qty numeric default 0, -- بالحبة
  pack_type text, -- كرتون / باكت / حبة
  pack_contains int, -- كم حبة داخل العبوة
  low_stock_threshold int default 5,
  supplier_id uuid,
  created_at timestamp default now(),
  updated_at timestamp default now(),
  is_deleted bool default false
);

-- 2. فواتير المبيعات
create table sales (
  id uuid primary key default gen_random_uuid(),
  invoice_no text unique,
  customer_id uuid,
  total numeric,
  paid numeric,
  remaining numeric,
  payment_type text, -- نقد / بطاقة / آجل
  cashier_id uuid,
  branch text,
  created_at timestamp default now(),
  synced bool default false
);

-- 3. تفاصيل فاتورة المبيعات
create table sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid references sales(id),
  item_id uuid references items(id),
  qty numeric,
  price numeric,
  total numeric
);

-- 4. المشتريات
create table purchases (
  id uuid primary key default gen_random_uuid(),
  invoice_no text,
  supplier_id uuid,
  total numeric,
  created_at timestamp default now()
);

-- 5. العملاء والموردين
create table customers (id uuid primary key default gen_random_uuid(), name text, phone text, balance numeric default 0);
create table suppliers (id uuid primary key default gen_random_uuid(), name text, phone text, balance numeric default 0);

-- 6. المرتجعات
create table returns (
  id uuid primary key default gen_random_uuid(),
  type text, -- بيع / شراء
  original_invoice_id uuid,
  reason text,
  created_at timestamp default now()
);

-- 7. المستخدمون والصلاحيات
create table users (
  id uuid primary key default gen_random_uuid(),
  username text unique,
  password_hash text,
  role text, -- مدير / كاشير / أمين مخزن
  permissions jsonb -- صلاحيات مرنة يختارها المدير
);

-- تفعيل Realtime للمزامنة
alter publication supabase_realtime add table items, sales, customers, suppliers;
