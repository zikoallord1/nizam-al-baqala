// Desktop POS - Tauri + SQLite Offline First
// سلة متعددة + بحث ذكي + عبوات

export default function App(){return <div>نظام البقالة - Desktop</div>}